import "./App.css";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import AdminLogin from "./Components/Admin/AdminLogin";
import UserLogin from "./Components/Users/UserLogin";
import Home from "./Components/Home";
function App() {
  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Home />}></Route>
          <Route
            path="/admin-login"
            element={
              <>
                <AdminLogin />
              </>
            }
          />
          <Route
            path="/user-login"
            element={
              <>
                <UserLogin />
              </>
            }
          />
        </Routes>
      </BrowserRouter>
    </>
  );
}

export default App;
