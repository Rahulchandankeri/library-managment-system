import React from "react";

function AdminLogin() {
  return <div>AdminLogin</div>;
}

export default AdminLogin;
