import React from "react";

function AdminPortal() {
  return <div>AdminPortal</div>;
}

export default AdminPortal;
